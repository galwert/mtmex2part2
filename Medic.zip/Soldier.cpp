//
// Created by galwe on 18/06/2021.
//

#include "Soldier.h"
namespace mtm {
    void Soldier::reload() {
        this->ammo += 3;
    }


    char Soldier::getLetter() {
        if (this->team == CROSSFITTERS) {
            return 's';
        } else {
            return 'S';
        }
    }

    int Soldier::getMaxMove() {
        return 3;
    }

    std::shared_ptr<Character> Soldier::clone() const {
        return std::shared_ptr<Character>(new Soldier(*this));
    }
}