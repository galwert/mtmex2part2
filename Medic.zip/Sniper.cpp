//
// Created by galwe on 18/06/2021.
//

#include "Sniper.h"
namespace mtm {
    void Sniper::reload() {
        this->ammo += 2;
    }


    char Sniper::getLetter() {
        if (this->team == CROSSFITTERS) {
            return 'n';
        } else {
            return 'N';
        }
    }

    int Sniper::getMaxMove() {
        return 4;
    }

    int Sniper::hitMultiplier() {
        if (this->hit == SECOND) {
            this->
                    hit = ZERO;
            return 2;
        }
        if (this->hit == FIRST) {
            this->
                    hit = SECOND;
        }
        if (this->hit == ZERO) {
            this->
                    hit = FIRST;
        }
        return 1;
    }

    std::shared_ptr<Character> Sniper::clone() const {
        return std::shared_ptr<Character>(new Sniper(*this));
    }
}