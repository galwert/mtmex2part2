//
// Created by galwe on 18/06/2021.
//

#include "Medic.h"
namespace mtm {
    void Medic::reload() {
        this->ammo += 5;
    }


    char Medic::getLetter() {
        if (this->team == CROSSFITTERS) {
            return 'm';
        } else {
            return 'M';
        }
    }

    int Medic::getMaxMove() {
        return 5;
    }

    std::shared_ptr<Character> Medic::clone() const {
        return std::shared_ptr<Character>(new Medic(*this));
    }
}